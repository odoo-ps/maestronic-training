# Ps-Tech module : Helpdesk Customization

Additional information on helpdesk.ticket with additional fields related to JIRA.
