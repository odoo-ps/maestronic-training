from . import helpdesk_concession
from . import helpdesk_ticket
from . import res_partner
from . import res_users
from . import repair_order
from . import helpdesk_team
from . import helpdesk_problem_category
from . import helpdesk_soultion_category
